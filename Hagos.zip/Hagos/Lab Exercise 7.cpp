#include  <iostream>
#include  <windows.h>
using namespace  std; 

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);

void gotoxy(short x, short y){ //n function to set console cursor
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
struct Item
{
	int code;
	char name [50]; 
	double price;
};

void displayitem (Item* &itm) ; 
void newline() ;

int main ()
{
	    cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                      LABORATORY 7                      |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
	Item* itm;
	itm = new Item;
	gotoxy(15,8); cout << "Enter Item Information: \n"; 
	gotoxy(15,9);cout << "Code: ";
	cin >> itm->code;
	newline();
	gotoxy(15,10);cout << "Name: " ;
	cin.getline (itm->name, 49);
	gotoxy(15,11);cout << "Price : ";
	cin >> itm->price;
	displayitem(itm);
	system("pause>0");

	return 0;
}

void displayitem (Item* &itm)
{
	gotoxy(40,8);cout << "Display Item Information :"; 
	gotoxy(40,9);cout << "Code : " << itm->code <<  endl;
	gotoxy(40,10);cout << "Name : " << itm->name  << endl;
	gotoxy(40,11);cout << "Price: " << itm->price  << endl;
}

void newline()
{
	char s;
	do{
		cin.get(s);
	} while(s != '\n');
	
}

