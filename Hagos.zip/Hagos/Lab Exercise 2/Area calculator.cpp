#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <stdlib.h>
#include <cmath>

using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);

int main(){
main:int x , q;	
	cout <<"         _______________________________________________________________  \n";
    cout <<"        .                                                               . \n";
    cout <<"       |    ________________________________________________________     |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                     AREA CALCULATOR                    |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                  [1] Area of Square                    |    |\n";
    cout <<"       |   |                  [2] Area of Rectangle                 |    |\n";
    cout <<"       |   |                  [3] Area of Triangle                  |    |\n";
    cout <<"       |   |                  [4] Area of Circle                    |    |\n";
    cout <<"       |   |                  [5] EXIT                              |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |               Choose an Option:                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |________________________________________________________|    |\n";
    cout <<"       |                                                                 |\n";
    cout <<"        ._______________________________________________________________. \n";
    cout <<"               .__________________________________________________.       \n";
	
	gotoXY(45,20);
	cin>>x;
	if (x > 0 && x < 6){
	switch (x)
	{
		case 1:{
			square:
			system("cls");
			int a, s;
			gotoXY(20,5); cout << "AREA OF A SQUARE CALCULATOR ";
			gotoXY(20,8); cout << "Side: ";
			cin >> s;
			gotoXY(20,10);
			if (s <= 0)
			{
				cout << "Side must be greater than zero";
			}
			else
			{	
				a = s * s;
				cout << "Area of Square: " << a << " unit/s." << endl;
			}
		option1:		
			gotoXY(20,15); cout<<"[1] RETRY"<<endl;
			gotoXY(20,16); cout<<"[2] MAIN MENU"<<endl;
			gotoXY(20,17); cout<<"[3] EXIT"<<endl;
			gotoXY(20,18); cout<<"Choose an Option: "<<endl;
			gotoXY(38,18);cin>>q;
			if (q==1)
			{
				system("cls"); 
				goto square;
			}
			else if (q==3)
			{
				system("cls"); 
				gotoXY(20,5); cout<< "THANK YOU!" << endl;
				gotoXY(20,6); cout<< "HAGOS, PHILIP P." << endl;
				gotoXY(20,7); cout<< "BS CpE 2-1" << endl;
			}
			else if (q == 2)		
			{
				system("cls"); 
				goto main;
			}
			else 
			{
				gotoXY(25, 20); cout<<"INVALID INPUT !!!";
				goto option1;
			}
			return 0;
		} 
		break;
		
		case 2:
		{
			rectangle:
			system("cls");
			int l, w, a;
			gotoXY(20,5); cout << "AREA OF RECTANGLE CALCULATOR ";
   			gotoXY(20,8); cout << "Length: ";
  			cin>>l;
  			gotoXY(20,9); cout << "Width: ";
   			cin>>w;
   			if (l <= 0 || w <= 0)
			{
				gotoXY(20,11); cout << "Side/s must be greater than zero";
			}
			else
			{	
				a = l * w;;
				gotoXY(20,11); cout << "Area of Rectangle: " << a << " unit/s." << endl;
			}
		option2:
			gotoXY(20,15); cout<<"[1] RETRY"<<endl;
			gotoXY(20,16); cout<<"[2] MAIN MENU"<<endl;
			gotoXY(20,17); cout<<"[3] EXIT"<<endl;
			gotoXY(20,18); cout<<"Choose an Option: "<<endl;
			gotoXY(38,18);cin>>q;
			if (q==1)
			{
				system("cls"); 
				goto rectangle;
			}
			else if (q==3)
			{
				system("cls"); 
				gotoXY(20,5); cout<< "THANK YOU!" << endl;
				gotoXY(20,6); cout<< "HAGOS, PHILIP P." << endl;
				gotoXY(20,7); cout<< "BS CpE 2-1" << endl;
			}
			else if (q == 2)		
			{
				system("cls"); goto main;
			}
			else 
			{
				gotoXY(25, 20); cout<<"INVALID INPUT !!!";
				goto option1;
			}
			return 0;
		} 
		break;
		
		case 3:{
			triangle:
			system("cls");
			int b, h;
			float a;
			gotoXY(20,5); cout << "AREA OF A TRIANGLE CALCULATOR ";
			gotoXY(20,8); cout << "Base: ";
  			cin>>b;
  			gotoXY(20,9);cout << "Height: ";
   			cin>>h;
   			if (b <= 0 || h <= 0)
			{
				gotoXY(20,11); cout << "Side/s must be greater than zero";
			}
			else
			{	
				a = (b*h)/2;
				gotoXY(20,11); cout << "Area of Triangle: " << a << " unit/s." << endl;
			}
	
		option3:
			gotoXY(20,13); cout<<"[1] RETRY"<<endl;
			gotoXY(20,14); cout<<"[2] MAIN MENU"<<endl;
			gotoXY(20,15); cout<<"[3] EXIT"<<endl;
			gotoXY(20,16); cout<<"Choose an Option: "<<endl;
			gotoXY(38,16);cin>>q;
			if (q==1)
			{
				system("cls"); 
				goto triangle;
			}
			else if (q==3)
			{
				system("cls"); 
				gotoXY(20,5); cout<< "THANK YOU!" << endl;
				gotoXY(20,6); cout<< "HAGOS, PHILIP P." << endl;
				gotoXY(20,7); cout<< "BS CpE 2-1" << endl;
			}
			else if (q == 2)		
			{
				system("cls"); goto main;
			}
			else 
			{
				gotoXY(25, 20); cout<<"INVALID INPUT !!!";
				goto option3;
			}
			return 0;
		} 
		break;
		
		case 4:{
			circle:
			system("cls");
			float r, a, Pi=3.14159265359;
			gotoXY(20,5); cout << "AREA OF A CIRCLE CALCULATOR ";
			gotoXY(20,8); cout << "Radius: ";
			cin >> r;
    		
    		
			if (r <= 0 )
			{
				gotoXY(20,11); cout << "Side/s must be greater than zero";
			}
			else
			{	
				a = Pi * r * r;
				gotoXY(20,11); cout << "Area of Circle: " << a << " unit/s." << endl;
			}
	
		option4:
			gotoXY(20,13); cout<<"[1] RETRY"<<endl;
			gotoXY(20,14); cout<<"[2] MAIN MENU"<<endl;
			gotoXY(20,15); cout<<"[3] EXIT"<<endl;
			gotoXY(20,16); cout<<"Choose an Option: "<<endl;
			gotoXY(38,16);cin>>q;
			if (q==1)
			{
				system("cls"); 
				goto circle;
			}
			else if (q==3)
			{
				system("cls"); 
				gotoXY(20,5); cout<< "THANK YOU!" << endl;
				gotoXY(20,6); cout<< "HAGOS, PHILIP P." << endl;
				gotoXY(20,7); cout<< "BS CpE 2-1" << endl;
			}
			else if (q == 2)		
			{
				system("cls"); goto main;
			}
			else 
			{
				gotoXY(25, 20); cout<<"INVALID INPUT !!!";
				goto option4;
			}
			return 0;
		}
		case 5:{
			system("cls"); 
			gotoXY(20,5); cout<< "THANK YOU!" << endl;
			gotoXY(20,6); cout<< "HAGOS, PHILIP P." << endl;
			gotoXY(20,7); cout<< "BS CpE 2-1" << endl;
		}
	}
	}
	else{
		gotoXY(25, 20); cout<<"INVALID INPUT !!!";
		system("cls");
		goto main;
}
}

void gotoXY(int x, int y) 
{ 
CursorPosition.X = x; // Locates column
CursorPosition.Y = y; // Locates Row
SetConsoleCursorPosition(console,CursorPosition); // Sets position for next thing to be printed 
}
