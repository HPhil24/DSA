#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <stdlib.h>
#include <cmath>
#include <sstream>  // for string streams 
#include <string>  // for string 


using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);
int main(){
tryagain:
    cout <<"         _______________________________________________________________  \n";
    cout <<"        .                                                               . \n";
    cout <<"       |    ________________________________________________________     |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                     ASCENDING ORDER                    |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |             Instructions: Enter 10 numbers             |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |        Unsorted:                    Sorted:            |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |________________________________________________________|    |\n";
    cout <<"       |                                                                 |\n";
    cout <<"        ._______________________________________________________________. \n";
    cout <<"               .__________________________________________________.       \n";
	
	string nums; int no=0,i,j,k;
	double Num[10],num[10],y=10, c;
	for(int i=0; i<10; i++){
		gotoXY(20,10+i);cout<<"["<<i+1<<"]";
		gotoXY(25,10+i); getline(cin,nums);

		for(int n1 = 0; n1<nums.length(); n1++){
			if(isalpha(nums[n1])){
				no++;
				goto turn;
			}
			else if(isdigit(nums[n1]) || nums[n1] == '.')
				no=0;
			else if(nums[n1] == ' '){
				no++;
				goto turn;
			}
			else{
				no++;
				goto turn;
			}
		}
		
		stringstream change(nums); 
		change >> Num[i];
	}
	cout<<endl;
	
    for(i=0; i<10; i++)
    {
        for(j=i+1; j<10; j++)
        {
            //Swap the smaller element found on the right of the array 
            if(Num[j] < Num[i])
            {
                k = Num[i];
                Num[i] = Num[j];
                Num[j] = k;
            }
        }
    }
	turn:
	if(no!=0 || nums.empty())
	{
		gotoXY(32,13);
		cout << "INVALID INPUT!";
	}
	else
	{
		for(i=0; i<10; i++)
    	{
    		gotoXY(52,10+i);
     		cout<<Num[i]<<"\t";
    	}
	}
	int back=0;

option:
	double option;
	gotoXY(22,21);
	cout << "[1] RETRY			[2] EXIT";
	if(back!=0){
	gotoXY(30,22); cout<<"INVALID SELECTION";
	}
	string opt;
	gotoXY(38,21); getline(cin,opt);
	for(int n1 = 0; n1<opt.length(); n1++){
			if(isalpha(opt[n1])){
				back++;	
				goto option;
			}
			else if(isdigit(opt[n1]) || opt[n1] == '.')
				back=0;
			else if(opt[n1] == ' '){
				back++;	
				goto option;
			}
			else{
				back++;	
				goto option;
			}
		}
	stringstream opts(opt);
	opts >> option;
	
	SetConsoleTextAttribute(hConsole, 15);
	if(option==1){
		system("cls");
		goto tryagain;
	}
	else if (option==2){
		system("cls");
    cout <<"         _______________________________________________________________  \n";
    cout <<"        .                                                               . \n";
    cout <<"       |    ________________________________________________________     |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                       THANK YOU!!!                     |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                     HAGOS, PHILIP P.                   |    |\n";
    cout <<"       |   |                        BS CpE 2-1                      |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |________________________________________________________|    |\n";
    cout <<"       |                                                                 |\n";
    cout <<"        ._______________________________________________________________. \n";
    cout <<"               .__________________________________________________.       \n";
	}
	else{	
	back++;	
		goto option;
	}
	
	
gotoXY(0,28); cout<<" ";
return 0;
}

void gotoXY(int x, int y) 
{ 
CursorPosition.X = x; // Locates column
CursorPosition.Y = y; // Locates Row
SetConsoleCursorPosition(console,CursorPosition); // Sets position for next thing to be printed 
}
