#include<iostream>
#include  <windows.h>
using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);

void gotoxy(short x, short y){ //n function to set console cursor
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
//Certificate of deposit account structure
struct CDAccount{
	double balance;
	double interestRate;
	int term;
};

CDAccount doubleInterest(CDAccount oldAccount);

void accountBalance(CDAccount& _account);

int main()
{
	CDAccount account;
	string option;
		cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                      LABORATORY 8                      |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
	gotoxy(15,8);cout<<"Enter account balance: PhP ";
	cin>>account.balance;
	gotoxy(15,9);cout<<"Enter account interest: ";
	cin>>account.interestRate;
	gotoxy(15,10);cout<<"Enter the number of months until maturity: ";
	cin>>account.term;
	
	accountBalance(account);
	
	gotoxy(15,12);cout<<"Old Account ";
	gotoxy(15,13);cout<<"when your CD matures in" <<endl;
	gotoxy(15,14);cout<<account.term<<" months, \n" <<endl;
	gotoxy(15,15);cout<<"it will have a balance of Php " <<account.balance<<endl;
		
	CDAccount accountNew;
	accountNew = doubleInterest(account);
	
	accountBalance(accountNew);
	
	gotoxy(15,17);cout<<"New Account" <<endl;
	gotoxy(15,18);	cout<<"when your CD matures in " << endl;
	gotoxy(15,19);	cout<<accountNew.term<<" months, \n" <<endl;
	gotoxy(15,20);	cout<<"it will have a balance of Php " <<accountNew.balance<<endl<<endl<<endl<<endl<<endl;

	return 0;
}

void accountBalance(CDAccount& _account)
{
	double rateFraction, interest;
	rateFraction = _account.interestRate/100.0;
	interest = _account.balance*(rateFraction*(_account.term/12.0));
	_account.balance = _account.balance + interest;
}

CDAccount doubleInterest(CDAccount oldAccount)
{
	CDAccount temp;
	temp = oldAccount;
	temp.interestRate = 2*oldAccount.interestRate;
	return temp;
}

