#include<iostream>
#include<cstring>
#include <windows.h>
using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);

void gotoxy(short x, short y){ //n function to set console cursor
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

int stringcompare(char *string1, char *string2);
void stringcat(char *string3, char *string4);
void stringcopy(char *string5, char *string6);
int stringlength(char *string7);
char* stringreverse(char*string8);
int main ()

{
	menu:
	system("cls");
		cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                      LABORATORY 3                      |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |               [1] STRING COMPARE                       |    |\n";
	    cout <<"       |   |               [2] STRING CONCATENATION                 |    |\n";
	    cout <<"       |   |               [3] STRING COPY                          |    |\n";
	    cout <<"       |   |               [4] STRING LENGTH                        |    |\n";
	    cout <<"       |   |               [5] STRING REVERSED                      |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |               Select a Program:                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
	gotoxy(45, 14);
	int choice;
	cin>>choice;
	cin.ignore(); 
	
	if (choice == 1)
	{
		system("cls");
		char string1[100];
		char string2[100];
		cout<<"Enter the first string: ";
		cin.getline(string1, 100);
		cout<<"Enter the second string: ";
		cin.getline(string2, 100);
 	
		cout<<"String Compare Value: "<<stringcompare(string1,string2)<<endl;
		system("pause");
		goto menu;
	}
	
	else if (choice == 2)
	{
		system("cls");
		char string3[100];
		char string4[100];
		cout<<"Enter the first string: ";
		cin.getline(string3, 100);
		cout<<"Enter the second string: ";
		cin.getline(string4, 100);
	
		stringcat(string3,string4);
		cout<<"New String: "<<string3<<endl;
		system("pause");
		goto menu;
	}
	
	else if (choice == 3)
	{
		system("cls");
		char string5[100];
		char string6[100];
		cout<<"Enter a string to copy: ";
		cin.getline(string6, 100);
		stringcopy(string5,string6);
		cout<<"string 1: "<<string5<<endl;
		cout<<"string 2: "<<string6<<endl;
		system("pause");
		goto menu;
	}
	
	else if (choice == 4)
	{
		system("cls");
		char string7[100];
		cout<<"Enter a string: ";
		cin.getline(string7, 100);
		cout<<"Length of the string: "<<stringlength(string7)<<endl;
		system("pause");
		goto menu;
	}
	
	else if (choice == 5)
	{
		system("cls");
		char string8[100];
		cout<<"Enter a string: ";
		cin.getline(string8, 100);
		cout<<"Reversed form of the string: "<<stringreverse(string8)<<endl;
		system("pause");
		goto menu;
	}
	
	else
	{
		cout<<"Invalid Input!"<<endl;
		system("pause");
		goto menu;
	}
	
	return 0;
}

int stringcompare(char *string1, char *string2)
{
	for (;*string1 == *string2; *string1++,*string2++)
	{
		if(*string1 == '\0' && *string2 == '\0')
		{
			return 0;
		}
		return *string1-*string2;
	}
}

void stringcat(char *string3, char *string4)
{
	while (*string3++);
	string3--;
	while(*string3++=*string4++);
	

}

void stringcopy(char *string5, char *string6)
{
	while (*string6 != '\0')
	{
		*string5 = *string6;
		string5++;
		string6++;
	}
	
	*string5 = '\0';
}

int stringlength(char *string7)
{
	int i;
	for(i = 0;string7[i]!='\0'; i++);
	return i;
}

char* stringreverse(char *string8)
{
	char *rev;
	rev = new char;
	int i, counter(0);
	
	for (i = 0; string8[i]!= '\0'; i++)
	{
		
		counter++;
	}
	for (i = 0;string8[counter]>= 0; i++)
	{
		rev[i] = string8[--counter];
	}
	
	rev[i] = '\0';
	return rev;
}
