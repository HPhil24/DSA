#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <stdlib.h>
#include <cmath>
#include <sstream>  // for string streams 
#include <string>  // for string 

using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);
int main(){
	SetConsoleTextAttribute(hConsole, 15);
	tryagain:
    cout <<"         _______________________________________________________________  \n";
    cout <<"        .                                                               . \n";
    cout <<"       |    ________________________________________________________     |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                     PALINDROME CHECKER                 |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |        Instructions: Enter phrase, words, numbers.     |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |________________________________________________________|    |\n";
    cout <<"       |                                                                 |\n";
    cout <<"        ._______________________________________________________________. \n";
    cout <<"               .__________________________________________________.       \n";
    char word[100];
    int i,y, len, check = 0;
	gotoXY(35,9); cin.getline(word,100);
    
    len = strlen(word);
    
    for(i=0;i < len ;i++){
        if(word[i] != word[len-i-1]){
            check = 1;
            break;
   		}
	}
	string s(word);
	
	gotoXY(30,15);  cout<<"Word: "<<s;
	gotoXY(30,17);
	if(check == 0)
	 	cout<<s<<" is a Palindrome";
	else if(check == 1)
		cout<<s<<" is a Not Palindrome";

	int back=0;
	
option:
	double option;
	gotoXY(22,20);
	cout << "[1] RETRY			[2] EXIT";
	string opt;
	if(back!=0){
	gotoXY(30,21); cout<<"INVALID SELECTION";
	}
	gotoXY(38,20); getline(cin,opt);
	for(int n1 = 0; n1<opt.length(); n1++){
			if(isalpha(opt[n1])){
				back++;	
				goto option;
			}
			else if(isdigit(opt[n1]) || opt[n1] == '.')
				back=0;
			else if(opt[n1] == ' '){
				back++;	
				goto option;
			}
			else{
				back++;	
				goto option;
			}
		}
	stringstream opts(opt);
	opts >> option;

	if(option==1){
		system("cls");
		goto tryagain;
	}
	else if (option==2){
		system("cls");
    cout <<"         _______________________________________________________________  \n";
    cout <<"        .                                                               . \n";
    cout <<"       |    ________________________________________________________     |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                       THANK YOU!!!                     |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                     HAGOS, PHILIP P.                   |    |\n";
    cout <<"       |   |                        BS CpE 2-1                      |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |________________________________________________________|    |\n";
    cout <<"       |                                                                 |\n";
    cout <<"        ._______________________________________________________________. \n";
    cout <<"               .__________________________________________________.       \n";
	}
	else{		
		back++;	
		goto option;
	}

			
gotoXY(0,22);	
return 0;
}

void gotoXY(int x, int y) 
{ 
CursorPosition.X = x; // Locates column
CursorPosition.Y = y; // Locates Row
SetConsoleCursorPosition(console,CursorPosition); // Sets position for next thing to be printed 
}
