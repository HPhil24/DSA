#include<iostream>
#include <windows.h>
using namespace std;
HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y); 
void printRow(int x, int y, int z)
{
	for(int i=0;i<=x; i++)
	{
		for(int j=0;j<=y; j++)
		{
			if(i==(x-1) && j==(y-1)){
			gotoXY(2+(i*4),1+(j*2)); cout<<z;
			}
		}
	}	
			gotoXY(0,31);	
}
int main(){
	int x,y,z;
	gotoXY(20,5); cout<<"-----------------------------------------"<<endl;
	gotoXY(20,6); cout<<"| 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |"<<endl;
	gotoXY(20,7); cout<<"-----------------------------------------"<<endl;
	gotoXY(20,8); cout<<"| 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |"<<endl;
    gotoXY(20,9); cout<<"-----------------------------------------"<<endl;
    gotoXY(20,10); cout<<"| 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |"<<endl;
    gotoXY(20,11); cout<<"-----------------------------------------" <<endl;
    gotoXY(20,12); cout<<"| 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |"<<endl;
    gotoXY(20,13); cout<<"-----------------------------------------"<<endl;
    gotoXY(20,14); cout<<"| 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 |"<<endl;
    gotoXY(20,15); cout<<"-----------------------------------------"<<endl;
    gotoXY(20,16); cout<<"| 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 |"<<endl;
    gotoXY(20,17); cout<<"-----------------------------------------" <<endl;
    gotoXY(20,18); cout<<"| 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |"<<endl;
    gotoXY(20,19); cout<<"-----------------------------------------"<<endl;
    gotoXY(20,20); cout<<"| 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 |"<<endl;
    gotoXY(20,21); cout<<"-----------------------------------------"<<endl;
    gotoXY(20,22); cout<<"| 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |"<<endl;
    gotoXY(20,23); cout<<"-----------------------------------------"<<endl;
    gotoXY(20,24); cout<<"| 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |"<<endl;
    gotoXY(20,25); cout<<"-----------------------------------------"<<endl<<endl;
    gotoXY(30,27);cout<<"Enter Column: ";
    gotoXY(45,27);cin>>x;
    gotoXY(30,28);cout<<"Enter Row: "<< endl;
    gotoXY(45,28);cin>>y;
    gotoXY(30,29);cout<<"Enter Number: "<< endl;
    gotoXY(45,29);cin>>z;
	printRow(x,y,z);


}
	                                                                                
void gotoXY(int x, int y) 
{ 
CursorPosition.X = x; // Locates column
CursorPosition.Y = y; // Locates Row
SetConsoleCursorPosition(console,CursorPosition); // Sets position for next thing to be printed 
}

