#include<iostream>
#include<cstring>
#include <windows.h>
using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);

void gotoxy(short x, short y){ //n function to set console cursor
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

struct onestudent
{
    char idnumber[50];
	char name[50];
    float quiz1;
	float quiz2;
	float quiz3;
};
struct student{
	int number;
	char idnumber[50];
	char name [50];
	float quiz1;
	float quiz2;
	float quiz3;
};
struct customer{
	int number;
	char firstname[50];
	char lastname[50];
	char contactnumber[50];
	int day;
	int month;
	int year;
	
	int itemIDone;
	char itemone[50];
	float priceone;
	int quantityone;
	
	int itemIDtwo;
	char itemtwo[50];
	float pricetwo;
	int quantitytwo;
	
	int itemIDthree;
	char itemthree[50];
	float pricethree;
	int quantitythree;

};
void StudentRecord()
{
	float grade;
	string remarksone;
	onestudent entryone;
	    cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
	gotoxy(20,5); cout<<"Enter Student Record:"<<endl;
	gotoxy(20,6);cout<<"ID Number: ";
	gotoxy(31,6);cin.getline(entryone.idnumber,50);
	gotoxy(20,7);cout<<"Name: ";
	gotoxy(30,7);cin.getline(entryone.name,50);
	gotoxy(20,8);cout<<"Quiz 1: ";
	gotoxy(30,8);cin>>entryone.quiz1;
	gotoxy(20,9);cout<<"Quiz 2: ";
	gotoxy(30,9);cin>>entryone.quiz2;
	gotoxy(20,10);cout<<"Quiz 3: ";
	gotoxy(30,10);cin>>entryone.quiz3;
	
	grade = (entryone.quiz1 + entryone.quiz2 + entryone.quiz3)/3;
	if (grade >= 75)
	{remarksone = "Passed";}
	else{remarksone = "Failed";}
	
	cout<<endl<<endl;
	gotoxy(50,7);cout<<"Student Record:"<<endl;
	gotoxy(50,8);cout<<"ID Number: "<<entryone.idnumber<<endl;
	gotoxy(50,9);cout<<"Name: "<<entryone.name<<endl;
	gotoxy(50,10);cout<<"Grade: "<<grade<<endl;
	gotoxy(50,11);cout<<"Remarks: "<<remarksone<<endl;
}

void MultipleStudentRecord ()
{
	student entrystudent[5];
	float ave[5];
	string remarks[5];
	for (int i = 0; i<5; i++)
	{
		entrystudent[i].number = i + 1;
		cout<<"Student number "<<entrystudent[i].number<<":"<<endl;
		cout<<"ID Number: ";
		cin>>entrystudent[i].idnumber;
		cout<<"Name: ";
		cin>>entrystudent[i].name;
		cout<<"Quiz 1: ";
		cin>>entrystudent[i].quiz1;
		cout<<"Quiz 2: ";
		cin>>entrystudent[i].quiz2;
		cout<<"Quiz 3: ";
		cin>>entrystudent[i].quiz3;
		cout<<"_________________________________________________"<<endl;
		ave[i] = (entrystudent[i].quiz1 + entrystudent[i].quiz2 + entrystudent[i].quiz3) / 3;
		if (ave[i] >= 75)
		{remarks[i] = "Passed";}
		else{remarks[i] = "Failed";}
	}
	
	cout<<"STUDENT RECORD"<<endl;
	
	
		for (int k = 0; k<5; k++)
		{
			cout<<entrystudent[k].number<<"\t\t";
			cout<<entrystudent[k].idnumber<<"\t\t\t\t";
			cout<<entrystudent[k].name<<"\t\t\t\t\t";
			cout<<ave[k]<<"\t\t";
			cout<<remarks[k];
			cout<<endl;
		}
}

void Customer ()
{
	customer entry[3];
	float totalprice[3];
	float quantitypriceone[3];
	float quantitypricetwo[3];
	float quantitypricethree[3];
	for (int i = 0; i<3; i++)
	{
		entry[i].number = i + 1;
		cout<<"CUSTOMER INFORMATION "<<entry[i].number<<":"<<endl;
		cout<<"First Name: ";
		cin>>entry[i].firstname;
		cout<<"Last Name: ";
		cin>>entry[i].lastname;
		cout<<"Contact No: ";
		cin>>entry[i].contactnumber;
		cout<<"Order Date:"<<endl;
		cout<<"Day: ";
		cin>>entry[i].day;
		cout<<"Month: ";
		cin>>entry[i].month;
		cout<<"Year: ";
		cin>>entry[i].year;
		cout<<"Enter 3 items: "<<endl;
		
		cout<<endl<<"ID: ";
		cin>>entry[i].itemIDone;
		cout<<"Name: ";
		cin>>entry[i].itemone;
		cout<<"Price: ";
		cin>>entry[i].priceone;
		cout<<"Quantity: ";
		cin>>entry[i].quantityone;
		quantitypriceone[i] = (entry[i].priceone * entry[i].quantityone);
		
		cout<<endl<<"ID: ";
		cin>>entry[i].itemIDtwo;
		cout<<"Name: ";
		cin>>entry[i].itemtwo;
		cout<<"Price: ";
		cin>>entry[i].pricetwo;
		cout<<"Quantity: ";
		cin>>entry[i].quantitytwo;
		quantitypricetwo[i] = (entry[i].pricetwo * entry[i].quantitytwo);
		
		cout<<endl<<"ID: ";
		cin>>entry[i].itemIDthree;
		cout<<"Name: ";
		cin>>entry[i].itemthree;
		cout<<"Price: ";
		cin>>entry[i].pricethree;
		cout<<"Quantity: ";
		cin>>entry[i].quantitythree;	
		cout<<endl<<endl;
		quantitypricethree[i] = (entry[i].pricethree * entry[i].quantitythree);
		
		totalprice[i] = quantitypriceone[i] + quantitypricetwo[i] + quantitypricethree[i];
		cout<<"_________________________________________________"<<endl;
	}
	
	cout<<endl<<endl<<endl;
	
	cout<<"Summary Report:"<<endl;
	cout<<"#"<<"\t\t\t"<<"Customer Name: "<<"\t\t\t"<<"Order Date: "<<"\t\t\t"<<"Items: "<<"\t\t\t"<<"Price"<<"\t\t\t"<<"Quantity"<<endl;
	
	cout<<entry[0].number<<"\t\t\t"<<entry[0].firstname<<", "<<entry[0].lastname<<"\t\t\t"<<entry[0].day<<"/"<<entry[0].month<<"/"<<entry[0].year<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t"<<entry[0].itemone<<"\t\t\t"<<entry[0].priceone<<"\t\t\t"<<entry[0].quantityone<<"\t\t\t"<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t"<<entry[0].itemtwo<<"\t\t\t"<<entry[0].pricetwo<<"\t\t\t"<<entry[0].quantitytwo<<"\t\t\t"<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t"<<entry[0].itemthree<<"\t\t\t"<<entry[0].pricethree<<"\t\t\t"<<entry[0].quantitythree<<"\t\t\t"<<endl;
	cout<<"\t\t\t\t\t"<<"TOTAL PRICE: "<<"\t\t\t\t\t"<<totalprice[0]<<endl<<endl;
	
	cout<<entry[1].number<<"\t\t\t"<<entry[1].firstname<<", "<<entry[1].lastname<<"\t\t\t"<<entry[1].day<<"/"<<entry[1].month<<"/"<<entry[1].year<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t"<<entry[1].itemone<<"\t\t\t"<<entry[1].priceone<<"\t\t\t"<<entry[1].quantityone<<"\t\t\t"<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t"<<entry[1].itemtwo<<"\t\t\t"<<entry[1].pricetwo<<"\t\t\t"<<entry[1].quantitytwo<<"\t\t\t"<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t"<<entry[1].itemthree<<"\t\t\t"<<entry[1].pricethree<<"\t\t\t"<<entry[1].quantitythree<<"\t\t\t"<<endl;
	cout<<"\t\t\t\t\t"<<"TOTAL PRICE: "<<"\t\t\t\t\t"<<totalprice[1]<<endl<<endl;
	
	cout<<entry[2].number<<"\t\t\t"<<entry[2].firstname<<", "<<entry[2].lastname<<"\t\t\t"<<entry[2].day<<"/"<<entry[2].month<<"/"<<entry[2].year<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t"<<entry[2].itemone<<"\t\t\t"<<entry[2].priceone<<"\t\t\t"<<entry[2].quantityone<<"\t\t\t"<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t"<<entry[2].itemtwo<<"\t\t\t"<<entry[2].pricetwo<<"\t\t\t"<<entry[2].quantitytwo<<"\t\t\t"<<endl;
	cout<<"\t\t\t\t\t\t\t\t\t"<<entry[2].itemthree<<"\t\t\t"<<entry[2].pricethree<<"\t\t\t"<<entry[2].quantitythree<<"\t\t\t"<<endl;
	cout<<"\t\t\t\t\t"<<"TOTAL PRICE: "<<"\t\t\t\t\t"<<totalprice[2]<<endl<<endl;
	
}

int main()
{
	menu:
	system("cls");
		cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                      LABORATORY 5                      |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |               [1] One Student Record                   |    |\n";
	    cout <<"       |   |               [2] Multiple Student Record              |    |\n";
	    cout <<"       |   |               [3] Customer Purchased                   |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |               Select a Program:                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";

	int choice;
	gotoxy(45, 14); 
	cin>>choice;
	cin.ignore();
	
	if (choice == 1)
	{
		system("cls");
		StudentRecord();
		system("pause");
		goto menu;
	}
	
	else if (choice == 2)
	{
		system("cls");
		MultipleStudentRecord();
		system("pause");
		goto menu;
	}
	
	else if (choice == 3)
	{
		system("cls");
		Customer();
		system("pause");
		goto menu;
	}
	
	else
	{
		cout<<"Invalid Input"<<endl;
		system("pause");
		system("cls");
		goto menu;
	}
	
	return 0;
	
}


