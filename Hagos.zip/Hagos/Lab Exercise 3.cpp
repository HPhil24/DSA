#include <algorithm>
#include <iostream> // Input and output
#include <string> // String usage
#include <fstream> // Text output (aesthetics)
#include <cmath>
#include <windows.h> // gotoxy() (replica of Turbo C++)
#include <vector>
#include <cstdlib>
#include<ctype.h>
#define MAX 100000

using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);

void gotoxy(short x, short y){ //n function to set console cursor
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

void textout(string filename){ // filestreaming text files
	system("cls");
	string line;
	ifstream file;
	file.open(filename.c_str());
	if (file.is_open()) {
		while (getline(file, line)) {
			cout << line << endl;
		}
		file.close();
	}
}

void capitalize_firstLetters_only(char str[MAX]){

	int i;
	//capitalize first character of words
	for(i=0; str[i]!='\0'; i++)
	{
		//check first character is lowercase alphabet
		if(i==0)
		{
			if((str[i]>='a' && str[i]<='z'))
				str[i]=str[i]-32; //subtract 32 to make it capital
			continue; //continue to the loop
		}
		if(str[i]==' ')//check space
		{
			//if space is found, check next character
			++i;
			//check next character is lowercase alphabet
			if(str[i]>='a' && str[i]<='z')
			{
				str[i]=str[i]-32; //subtract 32 to make it capital
				continue; //continue to the loop
			}
		}
		else
		{
			//all other uppercase characters should be in lowercase
			if(str[i]>='A' && str[i]<='Z')
				str[i]=str[i]+32; //subtract 32 to make it small/lowercase
		}
	}

	cout << "Capitalize string is: " << str << endl << endl;
}


bool isPalindrome(string str){

    str.erase(remove(str.begin(), str.end(), ' '), str.end());
    int length = str.length();

    for (int i = 0; i < (length / 2); i++)
        if (str[i] != str[length - 1 - i])
            return false;

    return true;
}

void reverseWords(string a)
{
    reverse(a.begin(), a.end());
    int s = 0;
    int i = 0;
    while(i < a.length())
    {
        if(a[i] == ' ')
        {
             reverse(a.begin() + s, a.begin() + i);
             s = i + 1;
        }
        i++;
    }
    if(a[a.length() - 1] != ' ')
    {
        reverse(a.begin() + s, a.end());
    }
    cout << "Reversed strings: " << a << endl << endl;
}



void error(){ // Display message for invalid inputs

	system("cls");
	textout("text\\error.txt");
	system("pause");
}

string tryAgain; // global variable if the user wants to try again

int main(){
    system("color 0a");     // Selection menu
a:	textout("text\\title.txt");
	string choice = "";
	string userInputs = "";
	    cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                      LABORATORY 3                      |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |               [1] STRING COMPARE                       |    |\n";
	    cout <<"       |   |               [2] STRING COPY                          |    |\n";
	    cout <<"       |   |               [3] STRING CONCATENATION                 |    |\n";
	    cout <<"       |   |               [4] PALINDROME                           |    |\n";
	    cout <<"       |   |               [5] CAPITALIZE FIRST LETTER              |    |\n";
	    cout <<"       |   |               [6] REVERSE                              |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |               Select a Program:                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
		gotoxy(45, 14); getline(cin, choice); // getline() for accommodating spaces (error handling)

b:	system("cls");
	if (choice == "1"){ // string compare
	    system("cls");
	    char userInputs1 [MAX]= "";
        char userInputs2 [MAX]= "";
        cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                     STRING COMPARE                     |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |        First string:                                   |    |\n";
	    cout <<"       |   |        Second string:                                  |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";


	    gotoXY(35,8); gets(userInputs1);
        gotoXY(36,9); gets(userInputs2);


        if (userInputs1[0] == '\0' || userInputs2[0] == '\0'){ // Error handler for no input char
            error();
            goto b;
        }

       char str1[MAX];
       char str2[MAX];
       int compare;

       strcpy(str1, userInputs1);
       strcpy(str2, userInputs2);

       compare = strcmp(str1, str2); // string compare
		gotoXY(33,11);
       if(compare < 0) {
          cout << "Comparison: Negative\n\n";
       }
       else if(compare > 0) {
          cout << "Comparison: Positive\n\n";
       }
       else {
          cout << "Comparison: Equal\n\n";
       }

       gotoXY(30,13); cout << "Try Again? (y/n): ";
       getline(cin, tryAgain);
       if(tryAgain == "y" || tryAgain == "Y"){
            string userInputs = "";
            goto b;
       }
       else if(tryAgain == "n" || tryAgain == "N"){
            system("pause"); 
			system("cls");
            goto a;
       }
       else{
            error();
            goto b;
       }

	}
	else if(choice == "2"){ // string copy
        system("cls");
        char userInputs1 [MAX]= ""; // Use string to accommodate all possible inputs
        char userInputs2 [MAX]= ""; // Use string to accommodate all possible inputs
        cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                       STRING COPY                      |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |        First string:                                   |    |\n";
	    cout <<"       |   |        Second string:                                  |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";

	    gotoXY(35,8); gets(userInputs1);
        gotoXY(36,9);gets(userInputs2);
		
       if (userInputs1[0] == '\0' || userInputs2[0] == '\0'){ // Error handler for no input char
            error();
            goto b;
        }

       strcpy(userInputs1, userInputs2); // string copy
                                        /* copy the second string and store into string 1 */

       gotoXY(33,11); cout << "First string: " << userInputs1 << endl << endl;

       gotoXY(30,13); cout << "Try Again? (y/n): ";
       getline(cin, tryAgain);
       if(tryAgain == "y" || tryAgain == "Y"){
            string userInputs = "";
            goto b;
       }
       else if(tryAgain == "n" || tryAgain == "N"){
            system("pause"); 
			system("cls");
            goto a;
       }
       else{
            error();
            goto b;
       }
	}

	else if(choice == "3"){ // string concatenate
        system("cls");
        char userInputs1 [MAX]= ""; // Use string to accommodate all possible inputs
        char userInputs2 [MAX]= ""; // Use string to accommodate all possible inputs
        string concatenatedString;
        cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                  STRING CONCATENATION                  |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |        First string:                                   |    |\n";
	    cout <<"       |   |        Second string:                                  |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";

	    gotoXY(35,8); gets(userInputs1);
        gotoXY(36,9); gets(userInputs2);

       if (userInputs1[0] == '\0' || userInputs2[0] == '\0'){ // Error handler for no input char
            error();
            goto b;
        }

       concatenatedString = strcat(userInputs1, userInputs2); // string concatenate

       gotoXY(33,11); cout << "Concatenated string: " << concatenatedString << endl << endl;

       gotoXY(30,13); cout << "Try Again? (y/n): ";
       getline(cin, tryAgain);
       if(tryAgain == "y" || tryAgain == "Y"){
            string userInputs = "";
            goto b;
       }
       else if(tryAgain == "n" || tryAgain == "N"){
            system("pause"); 
			system("cls");
            goto a;
       }
       else{
            error();
            goto b;
       }
	}

	else if(choice == "4"){ // Palindrome with spaces
        system("cls");
        char userInputs1 [MAX]= "";
        cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                        PALINDROME                      |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |        Enter a string:                                 |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
	    
		gotoXY(36,8); userInputs = gets(userInputs1); // for removing spaces

        if (userInputs1[0] == '\0'){ // Error handler for no input char
            error();
            goto b;
        }

        userInputs.erase(remove(userInputs.begin(), userInputs.end(), ' '), userInputs.end()); // removing spaces

        isPalindrome(userInputs1);

        gotoXY(33,11);
		if(isPalindrome(userInputs1)){
            cout << userInputs << " is a palindrome\n\n";
        }
        else {
            cout << userInputs << " is not palindrome\n\n";
        }

        gotoXY(30,13); cout << "Try Again? (y/n): ";
        getline(cin, tryAgain);

        if(tryAgain == "y" || tryAgain == "Y"){
            string userInputs = "";
            goto b;
        }
        else if(tryAgain == "n" || tryAgain == "N"){
            system("pause"); 
			system("cls");
            goto a;
        }
        else{
            error();
            goto b;
        }

	}

	else if(choice == "5"){ // Capitalize first letters of each word and lowercase the rest
        system("cls");
        char userInputs1 [MAX]= "";
        cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                 CAPITALIZE FIRST LETTER                |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |        Enter a string:                                 |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
        gotoXY(36,8); gets(userInputs1);
		gotoXY(33,11);
        if(userInputs1[0] == '\0'){ // Error handler for no input char
            error();
            goto b;
        }

        capitalize_firstLetters_only(userInputs1);

        gotoXY(30,13); cout << "Try Again? (y/n): ";
        getline(cin, tryAgain);

        if(tryAgain == "y" || tryAgain == "Y"){
            string userInputs = "";
            goto b;
        }
        else if(tryAgain == "n" || tryAgain == "N"){
            system("pause"); 
			system("cls");
            goto a;
        }
        else{
            error();
            goto b;
        }
	}

	if (choice == "6"){ // Reverse some strings
	    system("cls");
        cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                         REVERSE                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |        Enter a string:                                 |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
	    gotoXY(36,8); getline(cin, userInputs);

        if (userInputs[0] == '\0'){ // Error handler for no input char
            error();
            goto b;
        }
		gotoXY(33,11);
        reverseWords(userInputs);

        gotoXY(30,13); cout << "Try Again? (y/n): ";
        getline(cin, tryAgain);
        if(tryAgain == "y" || tryAgain == "Y"){
            string userInputs = "";
            goto b;
        }
        else if(tryAgain == "n" || tryAgain == "N"){
            cout << "\nReturning to main menu... "; system("pause"); system("cls");
            goto a;
        }
        else{
            error();
            goto b;
        }
	}


    else if(choice == "7"){
        exit(0); // exit program
    }
	else{ // all invalid inputs are error including white spaces
        error();
        goto a;
	}

}

void gotoXY(int x, int y) 
{ 
CursorPosition.X = x; // Locates column
CursorPosition.Y = y; // Locates Row
SetConsoleCursorPosition(console,CursorPosition); // Sets position for next thing to be printed 
}



