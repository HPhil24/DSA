#include <iostream>
#include <windows.h>
using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);

double max(double x, double y)
{	
	double high=0;
	if (x>y)
	{
		high = x;
	}else
	{
		high = y;
	}
	return high;

}
int main ()
{
	main:
	double x, y;
	double greatest;
	int q;
	cout <<"         _______________________________________________________________  \n";
    cout <<"        .                                                               . \n";
    cout <<"       |    ________________________________________________________     |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                      GREATEST NUMBER                   |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |              First number:                             |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |              Second Number:                            |    |\n";
    cout <<"       |   |                                                        |    |\n";    
	cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |________________________________________________________|    |\n";
    cout <<"       |                                                                 |\n";
    cout <<"        ._______________________________________________________________. \n";
    cout <<"               .__________________________________________________.       \n";
	gotoXY(40,11);cin >> x;
	gotoXY(41,13);cin >> y;

	if (x == y)
	{
	gotoXY(31,16); 	cout << "Numbers are equal.";
	}else
	{
	greatest = max (x, y);
	gotoXY(30,16); cout << "GREATEST NUMBER: " << greatest;
	cout << "\n\n\n\n"<< endl;}
	
	option:
	gotoXY(27,19);  cout<<"[1] RETRY          [2] EXIT"<<endl;
	gotoXY(40,20); cin>>q;

	if (q==1)
	{
		system("cls"); 
		goto main;
	}
	else if (q==2)
	{
		system("cls"); 
		gotoXY(20,5); cout<< "THANK YOU!" << endl;
		gotoXY(20,6); cout<< "HAGOS, PHILIP P." << endl;
		gotoXY(20,7); cout<< "BS CpE 2-1" << endl;
	}		
	else 
	{
		goto option;
	}

	return 0;
	
	
}
void gotoXY(int x, int y) 
{ 
CursorPosition.X = x; // Locates column
CursorPosition.Y = y; // Locates Row
SetConsoleCursorPosition(console,CursorPosition); // Sets position for next thing to be printed 
}
