#include <iostream>
#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include <stdlib.h>
#include <cmath>
#include <sstream>  // for string streams 
#include <string>  // for string 

using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);
int main(){
	retry:
	cout <<"         _______________________________________________________________  \n";
    cout <<"        .                                                               . \n";
    cout <<"       |    ________________________________________________________     |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                DECIMAL TO BINARY CONVERTER             |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |               Decimal:                                 |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |               Binary:                                  |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |                                                        |    |\n";
    cout <<"       |   |________________________________________________________|    |\n";
    cout <<"       |                                                                 |\n";
    cout <<"        ._______________________________________________________________. \n";
    cout <<"               .__________________________________________________.       \n";
	
	string x1;
	double X1,A;
	int Num[999];
	int num[999];
	int i=0, no=0;	
	gotoXY(36,12); getline(cin,x1);
	for(int n1 = 0; n1<x1.length(); n1++){
			if(isalpha(x1[n1])){
				no++;	
			}
			else if(isdigit(x1[n1]))
				no=no;
			else if(x1[n1] == ' '){
				no++;	
			}
			else{
				no++;
			}
		}
	stringstream xx(x1);
	xx >> X1;
	int X=X1;	
	if(no!=0)
	{
		gotoXY(36,14); cout<<"Error";			
	}
	else
	{
		gotoXY(36,14);
		while (X>=2)
		{
			A=X%2;
			X/=2;
			Num[i]=A;
			i++;
		}
		if(X>=0)
		{
			Num[i]=X;
			for(int j=0; j<=i; j++)
			{
				num[i-j]=Num[j];
			}
			
			for(int k=0; k<=i; k++)
			{
				cout<<num[k];
			}
		}
	}
	int back=0;
	option:	
	double option;
	string opt;
	gotoXY(27,18);  cout<<"[1] RETRY          [2] EXIT"<<endl;
	if(back!=0)
	{
		gotoXY(35,22); cout<<"INVALID INPUT";
		goto option;
	}
	
	gotoXY(40, 20); getline(cin,opt);
	for(int n1 = 0; n1<opt.length(); n1++){
			if(isalpha(opt[n1])){
				back++;	
				goto option;
			}
			else if(isdigit(opt[n1]) || opt[n1] == '.')
				back=0;
			else if(opt[n1] == ' '){
				back++;	
				goto option;
			}
			else{
				back++;	
				goto option;
			}
		}
	stringstream opts(opt);
	opts >> option;
	
	if(option==1)
	{
		system("cls");
		goto retry;
	}
	else if (option==2)
	{
		system("cls"); 
		gotoXY(20,5); cout<< "THANK YOU!" << endl;
		gotoXY(20,6); cout<< "HAGOS, PHILIP P." << endl;
		gotoXY(20,7); cout<< "BS CpE 2-1" << endl;
	}
	else{	
	back++;	
		goto option;
	}
	
			
gotoXY(0,22);	
return 0;
}

void gotoXY(int x, int y) 
{ 
CursorPosition.X = x; // Locates column
CursorPosition.Y = y; // Locates Row
SetConsoleCursorPosition(console,CursorPosition); // Sets position for next thing to be printed 
}
