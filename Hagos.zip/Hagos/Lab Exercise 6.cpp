#include <algorithm>
#include <iostream> // Input and output
#include <string> // String usage
#include <fstream> // Text output (aesthetics)
#include <cmath>
#include <windows.h> // gotoxy() (replica of Turbo C++)
#include <vector>
#include <cstdlib>
#include<ctype.h>
#define MAX 100000

using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoXY(int x, int y);

void gotoxy(short x, short y){ //n function to set console cursor
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

void textout(string filename){ // filestreaming text files
	system("cls");
	string line;
	ifstream file;
	file.open(filename.c_str());
	if (file.is_open()) {
		while (getline(file, line)) {
			cout << line << endl;
		}
		file.close();
	}
}

void error(){ // Display message for invalid inputs

	system("cls");
	textout("text\\error.txt");
	system("pause");
}

string tryAgain; // global variable if the user wants to try again

int main(){
    system("color 0a");     // Selection menu
a:	textout("text\\title.txt");
		cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                      LABORATORY 6                      |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |               [1] WRITE FILE                           |    |\n";
	    cout <<"       |   |               [2] READ FILE                            |    |\n";
	    cout <<"       |   |               [3] APPEND FILE                          |    |\n";
	    cout <<"       |   |               [4] WRITE FILE                           |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |               Select a Program:                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
	string choice = "";
	string userInputs = "";
	gotoxy(45, 14); getline(cin, choice); // getline() for accommodating spaces (error handling)

b:	system("cls");
	if (choice == "1"){
        system("cls");
        cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |       Press W/w to write file:                         |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
        cout << " ";
        gotoxy(45, 6);getline(cin, userInputs);

		
        if(userInputs == "W" || userInputs == "w"){
            FILE *fp;
            cout << endl;
            fp=fopen("text.txt", "w");
            if (!fp){
                gotoxy(30, 8);cout << "Cannot open file";

            }
            else{
                for(int i=65; i<91;i++){fputc(i,fp);}
                fclose(fp);
                gotoxy(30, 8);cout << "File written succesful !\n\n";
            }
        }

        else{
            error();
            goto b;
        }

         gotoxy(30, 11);cout << "Try Again? (y/n): ";
         gotoxy(50, 11);getline(cin, tryAgain);
         if(tryAgain == "y" || tryAgain == "Y"){
             string userInputs = "";
             goto b;
         }
         else if(tryAgain == "n" || tryAgain == "N"){
            system("pause"); 
			system("cls");
             goto a;
         }
         else{
             error();
             goto b;
         }

	}
	else if(choice == "2"){
        system("cls");
        cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |       Press R/r to read file:                          |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
        gotoxy(45, 6); getline(cin, userInputs);

        if(userInputs == "R" || userInputs == "r"){
            FILE *fp;
            fp=fopen("text.txt", "r");
            if (!fp){
                gotoxy(30, 8);cout << "Cannot open file";

            }
            else{
                char c;
                gotoxy(30, 8);cout << "Content of text.txt: \n";
                while((c=fgetc(fp))!=EOF){
                    gotoxy(30, 9);cout << c;
                }
                cout << endl << endl;
                fclose(fp);

            }
        }

        else{
            error();
            goto b;
        }

        gotoxy(30, 11);cout << "Try Again? (y/n): ";
        gotoxy(50, 11);getline(cin, tryAgain);
        if(tryAgain == "y" || tryAgain == "Y"){
             string userInputs = "";
             goto b;
        }
        else if(tryAgain == "n" || tryAgain == "N"){
             cout << "\nReturning to main menu... "; system("pause"); system("cls");
             goto a;
        }
        else{
             error();
             goto b;
        }
	 }

	else if(choice == "3"){
        system("cls");
        cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |       Press A/a to append file:                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
        cout << " ";
        gotoxy(45, 6);
        getline(cin, userInputs);

        if(userInputs == "A" || userInputs == "a"){
            FILE *fp;
            fp=fopen("text.txt", "a");
            if (!fp){
                gotoxy(30, 8);cout << "Cannot open file";

            }
            else{
                putc('\n',fp);
                for(int i=97; i<123;i++){fputc(i,fp);}
                fclose(fp);
                gotoxy(30, 8);cout << "File appending succesful !\n\n";
            }
        }

        else{
            error();
            goto b;
        }

       gotoxy(30, 11);cout << "Try Again? (y/n): ";
       gotoxy(50, 11);getline(cin, tryAgain);
       if(tryAgain == "y" || tryAgain == "Y"){
            string userInputs = "";
            goto b;
       }
       else if(tryAgain == "n" || tryAgain == "N"){
            system("pause"); 
			system("cls");
            goto a;
       }
       else{
            error();
            goto b;
       }

	}

	else if(choice == "4"){
        system("cls");
        cout <<"         _______________________________________________________________  \n";
	    cout <<"        .                                                               . \n";
	    cout <<"       |    ________________________________________________________     |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |       Press W/w to write file:                         |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |                                                        |    |\n";
	    cout <<"       |   |________________________________________________________|    |\n";
	    cout <<"       |                                                                 |\n";
	    cout <<"        ._______________________________________________________________. \n";
        cout << " ";
        gotoxy(45, 6);
        getline(cin, userInputs);


        if(userInputs == "W" || userInputs == "w"){
            FILE *fp;
            fp=fopen("text2.txt", "w");
            if (!fp){
                gotoxy(30, 8);cout << "Cannot open file";
            }
            else{
                fputs("sample string 1\n",fp);
                fputs("sample string 2",fp);
                fclose(fp);
                gotoxy(30, 8);cout << "File written succesful !\n\n";
            }
        }

        else{
            error();
            goto b;
        }

        gotoxy(30, 11);cout << "Try Again? (y/n): ";
        gotoxy(50, 11);getline(cin, tryAgain);

        if(tryAgain == "y" || tryAgain == "Y"){
            string userInputs = "";
            goto b;
        }
        else if(tryAgain == "n" || tryAgain == "N"){
            system("pause"); 
			system("cls");
            goto a;
        }
        else{
            error();
            goto b;
        }
	}


    else if(choice == "5"){
        exit(0); // exit program
    }
	else{ // all invalid inputs are error including white spaces
        error();
        goto a;
	}

}





